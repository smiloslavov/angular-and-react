let firstName = "Alice";
let age = 72;
let activeMember = true;

// firstName = 5;

let someVar;

function simpleFunction(name: string, isActive: boolean): number {
    // code goes here...
    return 0; // must return a number
}