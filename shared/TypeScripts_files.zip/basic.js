"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//there is no existing export by default which is why some of the errors occur
class Customer {
    constructor(name) {
        this.name = name;
    }
    announce() {
        return "Hello, my name is " + this.name;
    }
}
// create a new instance
let firstCustomer = new Customer("Alice");
let newMessage = firstCustomer.announce();
// change the text on the page
let webHeading = document.querySelector("h1");
webHeading.textContent = newMessage;
//note what happens if you remove the !
//the ! in TS acts as a non-null assertion operator
//This non-null assertion will remove null and undefined values.
//AT THE END OPEN TERMINAL AND TYPE
//tsc basic.ts
