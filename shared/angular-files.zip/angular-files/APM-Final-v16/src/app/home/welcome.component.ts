import { Component } from '@angular/core';

@Component({
    templateUrl: './welcome.component.html',
    standalone: true
})
export class WelcomeComponent {
  public pageTitle = 'Welcome';
}
