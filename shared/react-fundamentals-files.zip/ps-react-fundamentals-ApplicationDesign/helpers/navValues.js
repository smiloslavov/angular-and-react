const navValues = {
  home: "Home",
  house: "House",
};

export default navValues;
