import App from "../components/app";

const Index = () => <App />;

export default Index;
